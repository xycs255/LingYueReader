"""Base classes and interfaces for calibration.

This module provides the foundational classes that all calibrators inherit from,
as well as optional mixins for additional functionality like diagnostics.
Supports a modular architecture with concrete implementations in the
calibrators package.
"""

from __future__ import annotations

import logging

import numpy as np
from sklearn.base import BaseEstimator, TransformerMixin

logger = logging.getLogger(__name__)


class BaseCalibrator(BaseEstimator, TransformerMixin):
    """Base class for all calibrators.

    All calibrator classes should inherit from this base class to ensure
    consistent API and functionality. This follows the scikit-learn transformer
    interface with fit/transform/fit_transform methods.

    Args:
        enable_diagnostics: Whether to run plateau diagnostics after fitting.

    Notes:
        Subclasses implement :meth:`_fit_impl` and :meth:`transform`.
        The shared :meth:`fit` and :meth:`fit_transform` methods validate and
        retain the fitting data, maintain fitted state, and run diagnostics.

    Examples:
        >>> import numpy as np
        >>> from calibre import BaseCalibrator
        >>>
        >>> class SimpleCalibrator(BaseCalibrator):
        ...     def __init__(self, enable_diagnostics=False):
        ...         super().__init__(enable_diagnostics=enable_diagnostics)
        ...     def _fit_impl(self, X, y, sample_weight=None):
        ...         self.mean_ = np.mean(y)
        ...
        ...     def transform(self, X):
        ...         return np.full_like(X, self.mean_)
        >>>
        >>> X = np.array([0.1, 0.3, 0.5])
        >>> y = np.array([0, 1, 1])
        >>>
        >>> cal = SimpleCalibrator()
        >>> _ = cal.fit(X, y)
        >>> cal.transform(X)
        array([0.66666667, 0.66666667, 0.66666667])
    """

    def __init__(self, *, enable_diagnostics: bool = False) -> None:
        self.enable_diagnostics = enable_diagnostics
        self.diagnostics_: dict | None = None
        self._fit_data_X: np.ndarray | None = None
        self._fit_data_y: np.ndarray | None = None

    def fit(
        self,
        X: np.ndarray,
        y: np.ndarray,
        sample_weight: np.ndarray | None = None,
    ) -> BaseCalibrator:
        """Fit the calibrator.

        This method implements the template method pattern: it handles
        data storage and diagnostics, while delegating the actual fitting
        logic to the abstract _fit_impl() method that subclasses must implement.

        Args:
            X: The values to be calibrated (e.g., predicted probabilities).
            y: The target values (e.g., true labels).
            sample_weight: Non-negative per-observation weights. Calibrators
                that cannot honour weights raise rather than ignore them.

        Returns:
            BaseCalibrator: Returns self for method chaining.

        Raises:
            ValueError: If ``sample_weight`` is not one-dimensional, does not
                have the same shape as ``y``, contains a non-finite or negative
                value, or has no positive mass.
        """
        self._reset_fit_state()
        succeeded = False
        try:
            weight = None
            if sample_weight is not None:
                raw_weight = np.asarray(sample_weight)
                if raw_weight.ndim != 1:
                    raise ValueError("sample_weight must be 1-dimensional")
                if raw_weight.shape != np.asarray(y).shape:
                    raise ValueError("sample_weight must have the same shape as y")
                weight = np.asarray(sample_weight, dtype=float)
                if not np.all(np.isfinite(weight)) or np.any(weight < 0.0):
                    raise ValueError(
                        "sample_weight must contain finite non-negative values"
                    )
                if not np.any(weight > 0.0):
                    raise ValueError(
                        "sample_weight must contain at least one positive weight"
                    )
            self._fit_impl(X, y, weight)
            # Retain the same one-dimensional numeric representation accepted by the
            # concrete calibrators. Keeping the caller's raw list here made fitting
            # succeed and diagnostics fail later when they used NumPy index arrays.
            self._fit_data_X = np.asarray(X, dtype=float).ravel()
            self._fit_data_y = np.asarray(y, dtype=float).ravel()
            self._fit_data_weight = (
                None if weight is None else np.asarray(weight, dtype=float).ravel()
            )
            self._is_fitted = True
            self._run_diagnostics()
            succeeded = True
        finally:
            if not succeeded:
                self._reset_fit_state()

        return self

    def _reset_fit_state(self) -> None:
        """Remove learned state before fitting or after a failed refit."""
        for name in tuple(vars(self)):
            if name.endswith("_") and not name.startswith("__"):
                delattr(self, name)
        self.diagnostics_ = None
        self._fit_data_X = None
        self._fit_data_y = None
        self._fit_data_weight = None
        self._is_fitted = False

    def __sklearn_is_fitted__(self) -> bool:
        """Return whether :meth:`fit` completed successfully.

        Returns:
            bool: True after the template fitter completes, or after a custom
                subclass following scikit-learn's trailing-underscore convention
                has fitted itself.
        """
        if hasattr(self, "_is_fitted"):
            return bool(self._is_fitted)
        return any(
            name.endswith("_")
            and not name.startswith("__")
            and name != "diagnostics_"
            and value is not None
            for name, value in vars(self).items()
        )

    def _fit_impl(
        self,
        X: np.ndarray,
        y: np.ndarray,
        sample_weight: np.ndarray | None = None,
    ) -> None:
        """Implement the actual fitting logic.

        This abstract method must be implemented by subclasses to perform
        the calibration-specific fitting logic. The base fit() method handles
        data storage, diagnostics, and return value automatically.

        Args:
            X: The values to be calibrated (e.g., predicted probabilities).
            y: The target values (e.g., true labels).
            sample_weight: Non-negative per-observation weights.

        Raises:
            NotImplementedError: This method must be implemented by subclasses.

        Notes:
            Subclasses should implement this method instead of overriding fit().
            The fit() method in the base class ensures consistent behavior
            for diagnostics and data storage.

            Implementations must do all of their work here, so that ``transform``
            is a lookup against a fitted object rather than a re-solve.
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} must implement the _fit_impl() method"
        )

    def transform(self, X: np.ndarray) -> np.ndarray:
        """Apply calibration to new data.

        Args:
            X: The values to be calibrated.

        Returns:
            Calibrated values.

        Raises:
            NotImplementedError: This method must be implemented by subclasses.
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} must implement the transform() method"
        )

    def fit_transform(  # type: ignore[override]
        self,
        X: np.ndarray,
        y: np.ndarray,
        sample_weight: np.ndarray | None = None,
    ) -> np.ndarray:
        """Fit the calibrator and then transform the data.

        This is a convenience method that combines fit() and transform()
        in a single call. The default implementation simply calls fit()
        followed by transform().

        Args:
            X: The values to be calibrated.
            y: The target values.
            sample_weight: Non-negative per-observation weights.

        Returns:
            Calibrated values.

        Examples:
            >>> import numpy as np
            >>> from calibre import IsotonicCalibrator
            >>> X = np.array([0.1, 0.3, 0.5, 0.7, 0.9])
            >>> y = np.array([0, 0, 1, 1, 1])
            >>> cal = IsotonicCalibrator()
            >>> X_calibrated = cal.fit_transform(X, y)
        """
        return self.fit(X, y, sample_weight).transform(X)

    def _run_diagnostics(self) -> None:
        """Run diagnostic analysis on the fitted calibrator.

        This method is called automatically after fitting if enable_diagnostics=True.
        It calls the standalone diagnostic functions from the diagnostics module.
        """
        if (
            not self.enable_diagnostics
            or self._fit_data_X is None
            or self._fit_data_y is None
        ):
            return

        from .diagnostics import run_plateau_diagnostics

        try:
            diagnostic_x = self._fit_data_X
            if self._fit_data_weight is not None:
                diagnostic_x = diagnostic_x[self._fit_data_weight > 0.0]
            y_calibrated = self.transform(diagnostic_x)
            self.diagnostics_ = run_plateau_diagnostics(diagnostic_x, y_calibrated)
        except Exception as e:
            logger.warning("Diagnostic analysis failed: %s", e)
            self.diagnostics_ = None

    def has_diagnostics(self) -> bool:
        """Check if diagnostic information is available.

        Returns:
            has_diag: True if diagnostics have been computed and are available.

        Examples:
            >>> from calibre import IsotonicCalibrator
            >>> import numpy as np
            >>>
            >>> X = np.array([0.1, 0.3, 0.5])
            >>> y = np.array([0, 1, 1])
            >>>
            >>> cal = IsotonicCalibrator(enable_diagnostics=True)
            >>> _ = cal.fit(X, y)
            >>> cal.has_diagnostics()
            True
        """
        return self.diagnostics_ is not None

    def get_diagnostics(self) -> dict | None:
        """Get diagnostic results.

        Returns:
            dict | None: Diagnostic results from plateau analysis, or None if
                diagnostics were not computed or are not available.

        Examples:
            >>> from calibre import IsotonicCalibrator
            >>> import numpy as np
            >>>
            >>> X = np.array([0.1, 0.3, 0.5])
            >>> y = np.array([0, 1, 1])
            >>>
            >>> cal = IsotonicCalibrator(enable_diagnostics=True)
            >>> _ = cal.fit(X, y)
            >>> cal.get_diagnostics()["n_plateaus"]
            1
        """
        return self.diagnostics_

    def diagnostic_summary(self) -> str:
        """Get a human-readable summary of diagnostic analysis.

        Returns:
            summary: Human-readable plateau summary.

        Examples:
            >>> from calibre import IsotonicCalibrator
            >>> import numpy as np
            >>>
            >>> X = np.array([0.1, 0.3, 0.5, 0.7, 0.9])
            >>> y = np.array([0, 0, 1, 1, 1])
            >>>
            >>> cal = IsotonicCalibrator(enable_diagnostics=True)
            >>> _ = cal.fit(X, y)
            >>> print(cal.diagnostic_summary())
            Detected 2 plateau(s):
            <BLANKLINE>
            Warnings:
            ... Plateau 1 at [0.100, 0.300] has only 2 observations - may be unreliable
            ... Plateau 2 at [0.500, 0.900] has only 3 observations - may be unreliable
        """
        if not self.enable_diagnostics or self.diagnostics_ is None:
            return "Diagnostics not available. Set enable_diagnostics=True to enable."

        if self.diagnostics_["n_plateaus"] == 0:
            return "No plateaus detected in calibration curve."

        lines = [f"Detected {self.diagnostics_['n_plateaus']} plateau(s):"]

        if self.diagnostics_["warnings"]:
            lines.append("\nWarnings:")
            lines.extend(f"  ⚠ {warning}" for warning in self.diagnostics_["warnings"])

        return "\n".join(lines)


class MonotonicMixin:
    """Mixin for calibrators that maintain monotonicity.

    This mixin provides utility methods for calibrators that aim to
    preserve or enforce monotonic relationships between inputs and outputs.

    Methods:
        check_monotonicity(y): Check if an array is monotonically increasing.
        enforce_monotonicity(y): Enforce monotonicity on an array.

    Notes:
        This is a utility mixin that doesn't require any specific attributes.
        It's designed to be mixed in with BaseCalibrator subclasses that
        need monotonicity guarantees.
    """

    @staticmethod
    def check_monotonicity(y: np.ndarray, strict: bool = False) -> bool:
        """Check if an array is monotonically increasing.

        Args:
            y: Values to check for monotonicity.
            strict: If True, check for strictly increasing (no equal
                consecutive values). If False, check for non-decreasing
                (allows equal consecutive values).

        Returns:
            True if the array is monotonic according to the specified criteria.

        Examples:
            >>> import numpy as np
            >>> from calibre.base import MonotonicMixin
            >>>
            >>> y1 = np.array([0.1, 0.2, 0.3, 0.4])
            >>> MonotonicMixin.check_monotonicity(y1)
            True
            >>>
            >>> y2 = np.array([0.1, 0.3, 0.2, 0.4])
            >>> MonotonicMixin.check_monotonicity(y2)
            False
            >>>
            >>> y3 = np.array([0.1, 0.2, 0.2, 0.3])
            >>> MonotonicMixin.check_monotonicity(y3, strict=False)
            True
            >>> MonotonicMixin.check_monotonicity(y3, strict=True)
            False
        """
        y = np.asarray(y)
        if len(y) <= 1:
            return True

        diffs = np.diff(y)

        if strict:
            return bool(np.all(diffs > 0))
        return bool(np.all(diffs >= 0))

    @staticmethod
    def enforce_monotonicity(y: np.ndarray, inplace: bool = False) -> np.ndarray:
        """Enforce monotonicity on an array.

        This method ensures the array is non-decreasing by replacing any
        value that is less than the previous value with the previous value.

        Args:
            y: Values to make monotonic.
            inplace: If True, modify the array in place. Otherwise, return a copy.

        Returns:
            Monotonically increasing version of the input array.

        Examples:
            >>> import numpy as np
            >>> from calibre.base import MonotonicMixin
            >>>
            >>> y = np.array([0.1, 0.3, 0.2, 0.5, 0.4])
            >>> y_mono = MonotonicMixin.enforce_monotonicity(y)
            >>> print(y_mono)
            [0.1 0.3 0.3 0.5 0.5]
            >>>
            >>> # Original array unchanged
            >>> print(y)
            [0.1 0.3 0.2 0.5 0.4]
        """
        y_result = y if inplace else np.asarray(y).copy()

        for i in range(1, len(y_result)):
            if y_result[i] < y_result[i - 1]:
                y_result[i] = y_result[i - 1]

        return y_result


__all__ = [
    "BaseCalibrator",
    "MonotonicMixin",
]
